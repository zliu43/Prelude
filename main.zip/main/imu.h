#include "lsm6dso.h"
#include "lsm6dso_reg.h"
#include "spi_task_manager.h"
#include "esp_mac.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "esp_system.h"
#include "driver/gpio.h"

#define DEG2RAD 0.01745329251f
#define G_CONST 9.81f
#define DT 0.0048f 
#define ACC_SENSITIVITY (LSM6DSO_ACC_SENSITIVITY_FS_2G / 1000.0f * G_CONST) // ≈ 0.000598 m/s²
#define GYRO_SENSITIVITY (LSM6DSO_GYRO_SENSITIVITY_FS_250DPS / 1000.0f)  


volatile uint8_t IMU_INT_FLAG = 0;

static char* TAG_IMU = "IMU";
static QueueHandle_t spi_queue;
static spi_device_handle_t IMU_handle;
static SemaphoreHandle_t IMU_done;
static LSM6DSO_IO_t io_ctx;
static LSM6DSO_Object_t obj_ctx;    

int32_t imu_spi_platform_init(void)
{

    spi_queue = get_spi_queue();
    IMU_handle = get_imu_handle();
    IMU_done = xSemaphoreCreateBinary();
    if (spi_queue != NULL && IMU_handle != NULL){
        return 0;
    }
    ESP_LOGE(TAG_IMU, "FAILED TO INITIALIZE IMU_SPI");
    return -1;
}

int32_t lsm6dso_platform_write(void *handle, uint8_t reg, uint8_t *data, uint16_t len) {

    uint8_t *tx_data = malloc(len + 1);
    if (!tx_data) {
        return -1;
    }
    tx_data[0] = reg & 0x7F;
    memcpy(&tx_data[1], data, len);

    uint8_t *rx_data = malloc(1);  
    if (!rx_data) { 
        free(tx_data); return -1; 
    }

    spi_task_t *task = malloc(sizeof(spi_task_t)); 
    if (!task) { 
        free(tx_data); free(rx_data); return -1; 
    }

    task->device = IMU_handle;
    task->tx_buffer = tx_data;
    task->rx_buffer = rx_data;
    task->length = (len + 1) * 8;
    task->done = IMU_done;
    task->result = ESP_OK;

    xSemaphoreTake(task->done, 0);
    xQueueSend(spi_queue, &task, portMAX_DELAY);
    xSemaphoreTake(task->done, portMAX_DELAY);

    int res = (task->result == ESP_OK) ? 0 : -1;

    free((void *)task->tx_buffer);
    free((void *)task->rx_buffer);
    free(task);
    return res;
}

int32_t lsm6dso_platform_read(void *handle, uint8_t reg, uint8_t *data, uint16_t len) {
    spi_device_handle_t dev = get_imu_handle();

    // Allocate TX and RX buffers on the heap
    uint8_t *tx_data = malloc(len + 1);
    uint8_t *rx_data = malloc(len + 1);
    if (!tx_data || !rx_data) {
        free(tx_data);
        free(rx_data);
        return -1;
    }

    tx_data[0] = reg | 0x80;  // Set read bit

    // Allocate the task itself on the heap
    spi_task_t *read_task = malloc(sizeof(spi_task_t));
    if (!read_task) {
        free(tx_data);
        free(rx_data);
        return -1;
    }

    read_task->device = dev;
    read_task->tx_buffer = tx_data;
    read_task->rx_buffer = rx_data;
    read_task->length = (len + 1) * 8;
    read_task->done = IMU_done;
    read_task->result = ESP_OK;

    xSemaphoreTake(read_task->done, 0);  // reset semaphore
    xQueueSend(spi_queue, &read_task, portMAX_DELAY);  // send pointer
    xSemaphoreTake(read_task->done, portMAX_DELAY);  // wait for it to finish

    int result = (read_task->result == ESP_OK) ? 0 : -1;
 
    if (result == 0) {
        memcpy(data, &rx_data[1], len);
    }
 
    free((void *)read_task->tx_buffer);
    free((void *)read_task->rx_buffer);
    free(read_task);

    return result;
}

void lsm6dso_platform_delay(uint32_t milisec_delay){
    vTaskDelay(pdMS_TO_TICKS(milisec_delay));
}

int32_t lsm6dso_platform_get_tick(void) {
    return xTaskGetTickCount();  
}


void IRAM_ATTR imu_isr_handler(){
    IMU_INT_FLAG = 1;
}

void imu_init(){
    imu_spi_platform_init();
    stmdev_ctx_t dev_ctx = {
        .write_reg = lsm6dso_platform_write,
        .read_reg  = lsm6dso_platform_read,
        .mdelay    = lsm6dso_platform_delay,
        .handle    = get_imu_handle()
    };

    io_ctx = (LSM6DSO_IO_t){
        .Init     = imu_spi_platform_init,
        .DeInit   = NULL, 
        .BusType  = 1, 
        .Address  = NULL,    
        .WriteReg = lsm6dso_platform_write,
        .ReadReg  = lsm6dso_platform_read,
        .GetTick  = lsm6dso_platform_get_tick, 
        .Delay    = lsm6dso_platform_delay
    }; 
    obj_ctx = (LSM6DSO_Object_t){
        .IO             = io_ctx,
        .Ctx            = dev_ctx,
    };
    if (LSM6DSO_RegisterBusIO(&obj_ctx, &io_ctx) != LSM6DSO_OK){
        ESP_LOGI(TAG_IMU, "Failed to register BUS IO");
        return;
    }
    if (LSM6DSO_Init(&obj_ctx) != LSM6DSO_OK){
        ESP_LOGI(TAG_IMU, "Failed to Init LSM6DSO");
        return;
    }
    if (LSM6DSO_ACC_Enable(&obj_ctx) != LSM6DSO_OK){
        ESP_LOGI(TAG_IMU, "Failed to enable Accelerometer");
        return;
    }
    if (LSM6DSO_GYRO_Enable(&obj_ctx) != LSM6DSO_OK){
        ESP_LOGI(TAG_IMU, "Failed to enable Gyroscope");
        return;
    }

    LSM6DSO_ACC_SetOutputDataRate_With_Mode(&obj_ctx, 104.0f, LSM6DSO_ACC_HIGH_PERFORMANCE_MODE);
    LSM6DSO_ACC_Enable_Single_Tap_Detection(&obj_ctx, LSM6DSO_INT1_PIN);

    
    // Set pull-up and enable interrupt on rising edge for IMU_INT_PIN
    gpio_config_t imu_int_conf = {
        .intr_type = GPIO_INTR_POSEDGE,
        .mode = GPIO_MODE_INPUT,
        .pin_bit_mask = 1ULL << IMU_INT_PIN,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .pull_up_en = GPIO_PULLUP_ENABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&imu_int_conf));

    // Install ISR service if not already installed
    static bool isr_service_installed = false;
    if (!isr_service_installed) {
        ESP_ERROR_CHECK(gpio_install_isr_service(0));
        isr_service_installed = true;
    }

    // Add IMU ISR handler
    ESP_ERROR_CHECK(gpio_isr_handler_add(IMU_INT_PIN, imu_isr_handler, (void*)IMU_INT_PIN));
}

void imu_task(void *pvParameters){
    while(1){
        LSM6DSO_Axes_t accel_data;
        if(LSM6DSO_ACC_GetAxes(&obj_ctx, &accel_data) != LSM6DSO_OK){
            ESP_LOGI("ACC", "FAILED TO READ ACCEL DATA");
        }
        ESP_LOGI("ACC", "X: %d\tY: %d\tZ: %d", (int)accel_data.x, (int)accel_data.y, (int)accel_data.z);
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

static int16_t accel_x_data[1024] __attribute__((aligned(16)));
static int16_t accel_y_data[1024] __attribute__((aligned(16)));
static int16_t accel_z_data[1024] __attribute__((aligned(16)));

static int16_t gyro_x_data[1024] __attribute__((aligned(16)));
static int16_t gyro_y_data[1024] __attribute__((aligned(16)));
static int16_t gyro_z_data[1024] __attribute__((aligned(16)));

static unsigned int sample_idx;

typedef struct {
    int16_t ax, ay, az;
    bool accel_ready;
    int16_t gx, gy, gz;
    bool gyro_ready;
} SampleBuffer;

static SampleBuffer pending_sample = {0};

int16_t feature_mean(int16_t* data){
    int32_t sum = 0;
    for (int i = 0; i < 256; ++i){
        sum += data[i];
    }
    return (int16_t)(sum >> 8);
}

void calculate_features(const int index){
    int16_t x_acc_mean = feature_mean(&accel_x_data[index]) >> 4;
    int16_t y_acc_mean = feature_mean(&accel_y_data[index]) >> 4;
    int16_t z_acc_mean = feature_mean(&accel_z_data[index]) >> 4;
    int16_t x_gyro_mean = (feature_mean(&gyro_x_data[index]) * 9);
    int16_t y_gyro_mean = (feature_mean(&gyro_y_data[index]) * 9);
    int16_t z_gyro_mean = (feature_mean(&gyro_z_data[index]) * 9);


    ESP_LOGI("IMU",
        "Accel mean: x=%d , y=%d , z=%d | Gyro mean: x=%d , y=%d , z=%d ",
        x_acc_mean, y_acc_mean, z_acc_mean, 
        x_gyro_mean, y_gyro_mean, z_gyro_mean);
}



void imu_init_polling_mode() {
    // Set 208 Hz ODR without FIFO
    LSM6DSO_ACC_SetOutputDataRate_With_Mode(&obj_ctx, 208.0f, LSM6DSO_ACC_HIGH_PERFORMANCE_MODE);
    LSM6DSO_GYRO_SetOutputDataRate(&obj_ctx, LSM6DSO_GY_ODR_208Hz);
}

void imu_poll_read() {
    LSM6DSO_AxesRaw_t raw_accel;
    LSM6DSO_AxesRaw_t raw_gyro;

    if (LSM6DSO_ACC_GetAxesRaw(&obj_ctx, &raw_accel) == LSM6DSO_OK) {
        pending_sample.ax = raw_accel.x;
        pending_sample.ay = raw_accel.y;
        pending_sample.az = raw_accel.z;
        pending_sample.accel_ready = true;
    }

    if (LSM6DSO_GYRO_GetAxesRaw(&obj_ctx, &raw_gyro) == LSM6DSO_OK) {
        pending_sample.gx = raw_gyro.x;
        pending_sample.gy = raw_gyro.y;
        pending_sample.gz = raw_gyro.z;
        pending_sample.gyro_ready = true;
    }

    if (pending_sample.accel_ready && pending_sample.gyro_ready) {

        accel_x_data[sample_idx] = pending_sample.ax;
        accel_y_data[sample_idx] = pending_sample.ay;
        accel_z_data[sample_idx] = pending_sample.az;

        gyro_x_data[sample_idx] = pending_sample.gx;
        gyro_y_data[sample_idx] = pending_sample.gy;
        gyro_z_data[sample_idx] = pending_sample.gz;

        sample_idx++;

        if (sample_idx % 256 == 0) {
            switch (sample_idx) {
            case 256:
                calculate_features(0);
                break;
            case 528:
                calculate_features(256);
                break;
            case 784:
                calculate_features(528);
                break;
            case 1024:
                calculate_features(784);
                break;
            default:
                break;
            }
            sample_idx = sample_idx % 1024;
        }

        pending_sample.accel_ready = false;
        pending_sample.gyro_ready = false;
    }
}

void tracking_task(void* pvParameters) {
    imu_init_polling_mode();
    while (1) {
        imu_poll_read();
        vTaskDelay(pdMS_TO_TICKS(20));  
    }
}
