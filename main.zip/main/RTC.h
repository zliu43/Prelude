#include "freertos/semphr.h"
#include "freertos/FreeRTOS.h"
#include "esp_mac.h"
#include "freertos/task.h"
#include "i2c_task_manager.h"
#include "esp_log.h"
#include <string.h>

#define RV3028_I2C_ADDR       0x52  // 7-bit address
#define RV3028_REG_EEADDR     0x25
#define RV3028_REG_EEDATA     0x26
#define RV3028_REG_EECMD      0x27
#define RV3028_REG_STATUS     0x0E
#define RV3028_CMD_EEPROM_WRITE 0x21

typedef struct {
    uint8_t seconds;
    uint8_t minutes;
    uint8_t hours;
    uint8_t weekday;
    uint8_t days;
    uint8_t months;
    uint16_t years; 
} RTC_time_t;

RTC_time_t RTC_time;

SemaphoreHandle_t i2c_op_done;

static esp_err_t i2c_write_bytes(uint8_t reg, uint8_t *data, uint8_t len) {
    uint8_t buffer[1 + len];
    buffer[0] = reg;
    memcpy(&buffer[1], data, len);

    i2c_message_t msg = {
        .payload = buffer,
        .done = i2c_op_done,
        .length = len + 1,
        .address = RV3028_I2C_ADDR,
        .write = true
    };

    if (xQueueSend(i2c_queue, &msg, portMAX_DELAY) != pdTRUE) return ESP_FAIL;
    xSemaphoreTake(i2c_op_done, portMAX_DELAY);
    return msg.result;
}

static esp_err_t i2c_read_bytes(uint8_t reg, uint8_t *dest, uint8_t len) { 
    i2c_message_t reg_msg = {
        .payload = &reg,
        .done = i2c_op_done,
        .length = 1,
        .address = RV3028_I2C_ADDR,
        .write = true
    };

    if (xQueueSend(i2c_queue, &reg_msg, portMAX_DELAY) != pdTRUE) return ESP_FAIL;
    xSemaphoreTake(i2c_op_done, portMAX_DELAY);
    if (reg_msg.result != ESP_OK) return reg_msg.result;
 
    i2c_message_t msg = {
        .payload = dest,
        .done = i2c_op_done,
        .length = len,
        .address = RV3028_I2C_ADDR,
        .write = false
    };

    if (xQueueSend(i2c_queue, &msg, portMAX_DELAY) != pdTRUE) return ESP_FAIL;
    xSemaphoreTake(i2c_op_done, portMAX_DELAY);
    return msg.result;
}


esp_err_t rv3028_write_ram(uint8_t reg, uint8_t data, uint8_t length) {
    return i2c_write_bytes(reg, &data, length);
}

esp_err_t rv3028_read_ram(uint8_t reg, uint8_t *data, uint8_t length) {
    return i2c_read_bytes(reg, data, length);
}

esp_err_t rv3028_write_eeprom(uint8_t ee_addr, uint8_t data) {
    esp_err_t err;

    err = rv3028_write_ram(RV3028_REG_EEADDR, ee_addr, 1);
    if (err != ESP_OK) return err;

    err = rv3028_write_ram(RV3028_REG_EEDATA, data, 1);
    if (err != ESP_OK) return err;

    uint8_t cmd = RV3028_CMD_EEPROM_WRITE;
    err = rv3028_write_ram(RV3028_REG_EECMD, cmd, 1);
    if (err != ESP_OK) return err;

    uint8_t status = 0x80;
    do {
        err = rv3028_read_ram(RV3028_REG_STATUS, &status, 1);
        if (err != ESP_OK) return err;
        vTaskDelay(pdMS_TO_TICKS(2));
    } while (status & 0x80);

    return ESP_OK;
}

void RTC_init(){
    RTC_time = (RTC_time_t){0};
    if (!i2c_op_done) {
        i2c_op_done = xSemaphoreCreateBinary();
        assert(i2c_op_done != NULL);
    }
}

void RTC_read_time() {
    uint8_t raw[7];
    if (rv3028_read_ram(0x00, raw, 7) != ESP_OK) {
        ESP_LOGE("RTC", "Failed to read time registers");
        return;
    }

    RTC_time.seconds = ((raw[0] >> 4) * 10) + (raw[0] & 0x0F);
    RTC_time.minutes = ((raw[1] >> 4) * 10) + (raw[1] & 0x0F);
    RTC_time.hours   = ((raw[2] >> 4) * 10) + (raw[2] & 0x0F);
    RTC_time.weekday = raw[3] & 0x07; 
    RTC_time.days    = ((raw[4] >> 4) * 10) + (raw[4] & 0x0F);
    RTC_time.months  = ((raw[5] >> 4) * 10) + (raw[5] & 0x0F);
    RTC_time.years   = 2000 + ((raw[6] >> 4) * 10) + (raw[6] & 0x0F);
}

void RTC_set_time(const RTC_time_t *t) {
    uint8_t raw[7];
    raw[0] = ((t->seconds / 10) << 4) | (t->seconds % 10);
    raw[1] = ((t->minutes / 10) << 4) | (t->minutes % 10);
    raw[2] = ((t->hours / 10) << 4) | (t->hours % 10);
    raw[3] = t->weekday & 0x07;
    raw[4] = ((t->days / 10) << 4) | (t->days % 10);
    raw[5] = ((t->months / 10) << 4) | (t->months % 10);
    raw[6] = ((t->years % 100) / 10 << 4) | (t->years % 10);

    for (int i = 0; i < 7; ++i) {
        rv3028_write_ram(0x00 + i, raw[i], 1);
    }
}

void RTC_task(void* pvParameters){
    while(1){
        RTC_read_time();
        ESP_LOGI("RTC", "Time: %02u:%02u:%02u Date: %04u-%02u-%02u (Weekday: %u)",
         RTC_time.hours,
         RTC_time.minutes,
         RTC_time.seconds,
         RTC_time.years,
         RTC_time.months,
         RTC_time.days,
         RTC_time.weekday);
        vTaskDelay(100);
    }
}