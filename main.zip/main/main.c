#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_mac.h"
#include "esp_log.h"
#include "esp_chip_info.h"
#include "esp_system.h"
#include "esp_flash.h"

#include "imu.h"
#include "EVE.h"
#include "RTC.h"
#include "MCU.h"

#include "hardware_config.h"
#include "esp32_init.h" 
#include "i2c_task_manager.h"
#include "spi_task_manager.h"
#include "driver/gpio.h"

#define LED1 3
#define LED2 46


void imu_int_task(void *pvParameters){
    bool led_1_on = false;
    ESP_ERROR_CHECK(gpio_set_direction((gpio_num_t)LED1, GPIO_MODE_OUTPUT));
    while(1){
        if (IMU_INT_FLAG){
            ESP_LOGI("MAIN", "IMU_INT_DETECTED");
            led_1_on = !led_1_on;
            gpio_set_level(LED1,led_1_on);
            IMU_INT_FLAG = 0;
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

void app_main(void)
{   
    init_gpios();
    i2c_init();
    spi_init();
    imu_init();
    RTC_init();
    //TaskHandle_t imu_task_handle;
    //xTaskCreate(imu_task, "IMU_TASK", 4096, NULL, 10, &imu_task_handle);
    xTaskCreate(RTC_task, "rtc_task", 4096, NULL, 1, NULL);
    //EVE_Init();
    xTaskCreate(tracking_task, "tracking_task",262144, NULL,10,NULL);
    xTaskCreate(imu_int_task, "imu_int_task", 4096, NULL, 10, NULL);
}
